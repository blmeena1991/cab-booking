class Api::CabsController < Api::ApiController
  before_action :check_valid_params, only: [:book_nearest]

  def create
    @cab = Cab.new(create_params[:cab])
    @cab.save!
    render json: { cab: @cab.as_json }, status: :ok
  end

  def update
    @cab = Cab.find(params[:id])
    @cab.update!(update_params)
    render json: { cab: @cab.as_json }, status: :ok
  end

  def index
    cabs = Cab.available_cabs
    render json: { status: 'success', cabs: cabs }
  end

  def book_nearest
    color = params[:color].blank? ? nil : params[:color].to_s
    cab = Cab.nearest(params[:long].to_f, params[:lat].to_f, color)
    if cab.nil?
      response = { status: 'failure', message: 'Sorry no cabs are available' }
    else
      booking = cab.book(params[:user_id], params[:long], params[:lat])
      if booking
        response = { status: 'success', cab: cab, booking_id: booking.id, message: 'Booking Success' }
      else
        response = { status: 'failure', message: 'Sorry! Failed to book trip' }
      end
    end
    render json: response
  end

  def check_valid_params
    if params[:lat].nil? || params[:long].nil? || params[:user_id].nil?
      render json: { status: 'failure', message: 'Bad Request! Please enter proper params' }, status: 400
    end
  end

  private

  def create_params
    params.permit(cab: [:registration_number, :status,:color,:modelname, :lat,:long])
  end

  def update_params
    params.permit(cab: [:lat,:long])
  end
end
