class Api::UsersController < Api::ApiController
  def create
    @user = User.new(create_params[:user])
    @user.save!
    render json: { user: @user.as_json }, status: :ok
  end

  def booking_history
    @user =  User.find(params[:user_id])
    unless @user.driver?
      response = { status: 'failure', message: "Sorry.Unable to access" }
    end
    @history = Booking.joins(:user).where(user_id: params[:user_id]).merge(User.driver).order(created_at: :desc)
    render json: @history.as_json
  end

  def register_cab_driver
    @user = User.find(params[:id])
    @cab =  Cab.find(params[:cab_id])
    user_cab = UserCabRelation.new
    user_cab.user = @user
    user_cab.cab = @cab
    user_cab.save!
    render json: { message: "Cab link to driver" }, status: :ok
  end

  private

  def create_params
    params.permit(user: [:name, :long,:lat,:user_type])
  end

  def create_driver_params
    params.permit(user: [:name, :long,:lat,:user_type])
  end
end
