class User < ApplicationRecord
  validates_presence_of :name
  validates_uniqueness_of :name

  has_one :user_cab_relation
  has_many :bookings
  enum user_type: [:rider, :driver]


end
