class UserCabRelation < ApplicationRecord
  belongs_to :cab
  belongs_to :user
  validates_uniqueness_of :user_id, scope: [:cab_id]
end
