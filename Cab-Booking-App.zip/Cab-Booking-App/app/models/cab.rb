class Cab < ApplicationRecord
  has_many :bookings
  has_one :user_cab_relation
  validates_presence_of :registration_number, :status, :lat, :long
  validates_uniqueness_of :registration_number
  scope :available_cabs, -> { where(status: 'available').order(created_at: 'desc') }
  scope :pink_available_cabs, -> { available_cabs.where(color: 'pink') }

  def book(user_id, lat, long)
    return false unless available?
    update_attribute(:status, 'booked')
    Booking.create!(cab_id: id, user_id: user_id, starting_lat: lat, starting_long: long, status: 'scheduled')
  end

  def booked?
    status == "booked"
  end

  def available?
    status == "available"
  end

  def self.car_list(color = nil)
    color == 'pink' ? pink_available_cabs : available_cabs
  end

  def self.nearest(lat, long, color = nil)
    nearest_cab = nil
    shortest_distance = Float::INFINITY
    car_list(color).each do |cab|
      distance = Math.sqrt((lat - cab.lat)**2 + (long - cab.lat)**2)
      if distance < shortest_distance
        shortest_distance = distance
        nearest_cab = cab
      end
    end
    nearest_cab
  end
end
