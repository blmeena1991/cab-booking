namespace :api, defaults: { format: :json } do
  resources :users, path: 'users', only: [:index, :show, :create,:update] do
    member do
      get :booking_history, path: 'booking_history'
      put :register_cab_driver, path: "register-cab"
    end
  end
  resources :cabs, path: 'users', only: [:index, :show, :create,:update]

  resources :cabs, only: [:index, :show, :create,:update], defaults: { format: :json } do
    collection do
      get :book_nearest, path: 'book-nearest'
    end
  end

  resources :bookings, only: [], defaults: { format: :json } do
    member do
      post 'start'
      post 'end'
    end
  end
end
