# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 2020_04_25_061907) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "bookings", force: :cascade do |t|
    t.float "starting_lat", null: false
    t.float "starting_long", null: false
    t.float "ending_lat"
    t.float "ending_long"
    t.datetime "start_time"
    t.datetime "end_time"
    t.integer "status", null: false
    t.float "amount"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "user_id"
    t.bigint "cab_id"
    t.index ["cab_id"], name: "index_bookings_on_cab_id"
    t.index ["user_id"], name: "index_bookings_on_user_id"
  end

  create_table "cabs", force: :cascade do |t|
    t.string "registration_number", null: false
    t.string "status", null: false
    t.string "color"
    t.string "modelname"
    t.float "lat", null: false
    t.float "long", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "user_cab_relations", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "user_id"
    t.bigint "cab_id"
    t.index ["cab_id"], name: "index_user_cab_relations_on_cab_id"
    t.index ["user_id"], name: "index_user_cab_relations_on_user_id"
  end

  create_table "users", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "name", null: false
    t.integer "user_type", null: false
    t.float "long", null: false
    t.float "lat", null: false
  end

  add_foreign_key "bookings", "cabs"
  add_foreign_key "bookings", "users"
  add_foreign_key "user_cab_relations", "cabs"
  add_foreign_key "user_cab_relations", "users"
end
