class CreateUsers < ActiveRecord::Migration[5.2]
  def change
    create_table :users do |t|
      t.timestamps
      t.string :name, null: false
      t.integer :user_type, null: false
      t.float :long, null: false
      t.float :lat, null: false
    end
  end
end
